const HttpBaseConstant = {
    url: window.globalConfig.url,
    login:window.globalConfig.login
}

export default HttpBaseConstant