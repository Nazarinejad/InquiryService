export interface IGetRequestBody {
    PolicyUniqueCode : string
    NationalCode : string
}
