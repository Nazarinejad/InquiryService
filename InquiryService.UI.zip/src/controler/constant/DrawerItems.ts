const DRAWER_ITEMS = [
    {
        title: "صورتهای مالی",
        links: [
            {
                path: "financial",
                //icon: <img src={reffer} alt="reffer" />,
                title: "صورتهای مالی",
            },
            {
                path: "createInformation",
                //icon: <img src={send} alt="send" />,
                title: "اطلاعات پایه",
            },

        ],

    },
];

export default DRAWER_ITEMS