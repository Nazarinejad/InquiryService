const LINKS = {
    REPORT: "report",
    REPORT_MANAGEMENT: "report-management",
    DASHBOARD: "dashboard",
}

export  default LINKS