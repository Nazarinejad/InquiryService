export interface IGETAllRequestBody {
    pageNumber: number | undefined
    pageItemCount: number | undefined
    fieldId: number,
    companyId: number
}

export interface IGetbYiDRequestBody {
    id: number
}
