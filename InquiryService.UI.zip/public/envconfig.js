window.globalConfig = {
    url: "http://inquiry.centinsur.test/api",
	login: "http://sanhabcrdmng.centinsur.test/back/api",
}
